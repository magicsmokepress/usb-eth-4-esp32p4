USBEth — USB Ethernet for ESP32-P4
===================================

INSTALLATION
------------
Windows:  Double-click install.bat
Linux/Mac: bash install.sh (from WSL or terminal)

The installer will:
  1. Copy the USBEth library to your Arduino libraries folder
  2. If M5Stack Tab5 BSP is detected, patch it automatically

After installation, open Arduino IDE:
  File -> Examples -> USBEth -> BasicEthernet

WHAT'S INSIDE
-------------
USBEth/              Arduino library (source + examples)
tab5-bsp-patch/      M5Stack Tab5 BSP patch (libs + headers)
install.bat          Windows installer
install.sh           Linux/Mac installer (WSL)

MORE INFO
---------
https://github.com/magicsmokepress/usb-eth-4-esp32p4
