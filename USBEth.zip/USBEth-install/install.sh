#!/bin/bash
# USBEth Installer — USB Ethernet for ESP32-P4
# Installs the Arduino library and patches M5Stack Tab5 BSP if found.

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "======================================================"
echo "  USBEth Installer — USB Ethernet for ESP32-P4"
echo "======================================================"
echo

# ── Step 1: Find Arduino libraries folder ──────────────────
ARDUINO_LIBS=""
for dir in \
    "$HOME/Arduino/libraries" \
    "$HOME/Documents/Arduino/libraries" \
    "$HOME/OneDrive/Documents/Arduino/libraries"; do
    if [ -d "$dir" ]; then
        ARDUINO_LIBS="$dir"
    fi
done

if [ -z "$ARDUINO_LIBS" ]; then
    for dir in /mnt/c/Users/*/Documents/Arduino/libraries \
               /mnt/c/Users/*/OneDrive/Documents/Arduino/libraries; do
        found=$(ls -d $dir 2>/dev/null | head -1)
        if [ -n "$found" ]; then
            ARDUINO_LIBS="$found"
        fi
    done
fi

if [ -z "$ARDUINO_LIBS" ]; then
    echo "ERROR: Cannot find Arduino libraries folder."
    echo "Create ~/Arduino/libraries/ or install Arduino IDE first."
    exit 1
fi

echo "Found Arduino libraries: $ARDUINO_LIBS"

# ── Step 2: Install USBEth library ─────────────────────────
echo
echo "Step 1: Installing USBEth library..."
if [ -d "$ARDUINO_LIBS/USBEth" ]; then
    echo "  Removing old USBEth library..."
    rm -rf "$ARDUINO_LIBS/USBEth"
fi
cp -r "$SCRIPT_DIR/USBEth" "$ARDUINO_LIBS/"
echo "  Done."

# ── Step 3: Find M5Stack BSP ──────────────────────────────
BSP_P4=""
for pattern in \
    "/mnt/c/Users/*/AppData/Local/Arduino15/packages/m5stack/tools/esp32-arduino-libs/*/esp32p4" \
    "$HOME/Library/Arduino15/packages/m5stack/tools/esp32-arduino-libs/*/esp32p4" \
    "$HOME/.arduino15/packages/m5stack/tools/esp32-arduino-libs/*/esp32p4"; do
    found=$(ls -d $pattern 2>/dev/null | head -1)
    if [ -n "$found" ]; then
        BSP_P4="$found"
    fi
done

if [ -z "$BSP_P4" ]; then
    echo
    echo "No M5Stack BSP found — skipping BSP patch."
    echo "  This is fine if you are not using a Tab5."
    echo
    echo "======================================================"
    echo "  USBEth library installed successfully!"
    echo "  Open Arduino IDE, go to:"
    echo "  File -> Examples -> USBEth -> BasicEthernet"
    echo "======================================================"
    exit 0
fi

echo
echo "Found M5Stack BSP: $BSP_P4"
echo
echo "Step 2: Patching M5Stack BSP for Tab5..."

# ── Run the BSP patch install.sh ───────────────────────────
bash "$SCRIPT_DIR/tab5-bsp-patch/install.sh" "$BSP_P4"

echo
echo "======================================================"
echo "  USBEth installed successfully!"
echo
echo "  Library:   $ARDUINO_LIBS/USBEth"
echo "  BSP patch: $BSP_P4"
echo
echo "  Next steps:"
echo "  1. Open Arduino IDE"
echo "  2. Select board: M5Stack Tab5"
echo "  3. File -> Examples -> USBEth -> BasicEthernet"
echo "  4. Compile and flash"
echo "======================================================"
