@echo off
setlocal enabledelayedexpansion

echo ======================================================
echo   USBEth Installer — USB Ethernet for ESP32-P4
echo ======================================================
echo.

set "SCRIPT_DIR=%~dp0"

:: ── Step 1: Find Arduino libraries folder ──────────────────
set "ARDUINO_LIBS="
for %%D in (
    "%USERPROFILE%\Documents\Arduino\libraries"
    "%USERPROFILE%\OneDrive\Documents\Arduino\libraries"
    "%USERPROFILE%\Arduino\libraries"
) do (
    if exist "%%~D" (
        set "ARDUINO_LIBS=%%~D"
    )
)

if not defined ARDUINO_LIBS (
    echo ERROR: Cannot find Arduino libraries folder.
    echo Looked in:
    echo   %USERPROFILE%\Documents\Arduino\libraries
    echo   %USERPROFILE%\OneDrive\Documents\Arduino\libraries
    echo   %USERPROFILE%\Arduino\libraries
    echo.
    echo Create it manually or install Arduino IDE first.
    pause
    exit /b 1
)

echo Found Arduino libraries: %ARDUINO_LIBS%

:: ── Step 2: Install USBEth library ─────────────────────────
echo.
echo Step 1: Installing USBEth library...
if exist "%ARDUINO_LIBS%\USBEth" (
    echo   Removing old USBEth library...
    rmdir /s /q "%ARDUINO_LIBS%\USBEth"
)
xcopy /s /e /i /q "%SCRIPT_DIR%USBEth" "%ARDUINO_LIBS%\USBEth"
echo   Done.

:: ── Step 3: Find M5Stack BSP (Tab5 only) ──────────────────
set "BSP_P4="
for /d %%V in ("%LOCALAPPDATA%\Arduino15\packages\m5stack\tools\esp32-arduino-libs\*") do (
    if exist "%%V\esp32p4" (
        set "BSP_P4=%%V\esp32p4"
    )
)

if not defined BSP_P4 (
    echo.
    echo No M5Stack BSP found — skipping BSP patch.
    echo   This is fine if you are not using a Tab5.
    echo.
    echo ======================================================
    echo   USBEth library installed successfully!
    echo   Open Arduino IDE, go to:
    echo   File -^> Examples -^> USBEth -^> BasicEthernet
    echo ======================================================
    pause
    exit /b 0
)

echo.
echo Found M5Stack BSP: %BSP_P4%
echo.
echo Step 2: Patching M5Stack BSP for Tab5...
echo   (This is needed because the Tab5 BSP ships without
echo    USB Ethernet support enabled)
echo.

:: ── Step 4: Backup originals ───────────────────────────────
echo   Backing up original files...
if exist "%BSP_P4%\lib\libusb.a" if not exist "%BSP_P4%\lib\libusb.a.bak" (
    copy "%BSP_P4%\lib\libusb.a" "%BSP_P4%\lib\libusb.a.bak" >nul
    echo     Backed up: libusb.a
)
if exist "%BSP_P4%\lib\liblwip.a" if not exist "%BSP_P4%\lib\liblwip.a.bak" (
    copy "%BSP_P4%\lib\liblwip.a" "%BSP_P4%\lib\liblwip.a.bak" >nul
    echo     Backed up: liblwip.a
)
if exist "%BSP_P4%\flags\ld_libs" if not exist "%BSP_P4%\flags\ld_libs.bak" (
    copy "%BSP_P4%\flags\ld_libs" "%BSP_P4%\flags\ld_libs.bak" >nul
    echo     Backed up: ld_libs
)
if exist "%BSP_P4%\flags\includes" if not exist "%BSP_P4%\flags\includes.bak" (
    copy "%BSP_P4%\flags\includes" "%BSP_P4%\flags\includes.bak" >nul
    echo     Backed up: includes
)
if exist "%BSP_P4%\sdkconfig" if not exist "%BSP_P4%\sdkconfig.bak" (
    copy "%BSP_P4%\sdkconfig" "%BSP_P4%\sdkconfig.bak" >nul
    echo     Backed up: sdkconfig
)

:: ── Step 5: Install libraries ──────────────────────────────
echo   Installing libraries...
for %%F in ("%SCRIPT_DIR%tab5-bsp-patch\lib\*.a") do (
    copy "%%F" "%BSP_P4%\lib\" >nul
    echo     Installed: %%~nxF
)

:: ── Step 6: Install headers ────────────────────────────────
echo   Installing headers...
for /d %%D in ("%SCRIPT_DIR%tab5-bsp-patch\include\*") do (
    xcopy /s /e /i /q "%%D" "%BSP_P4%\include\%%~nxD" >nul
    echo     Installed: %%~nxD\
)

:: ── Step 7: Patch include flags ────────────────────────────
echo   Patching include flags...
set "INCLUDES_FILE=%BSP_P4%\flags\includes"
for %%E in (
    "-iwithprefixbefore/espressif__iot_eth"
    "-iwithprefixbefore/espressif__iot_usbh_cdc"
    "-iwithprefixbefore/espressif__iot_usbh_ecm"
    "-iwithprefixbefore/usb_eth_deps"
) do (
    findstr /c:"%%~E" "%INCLUDES_FILE%" >nul 2>&1
    if errorlevel 1 (
        echo  %%~E>> "%INCLUDES_FILE%"
        echo     Added: %%~E
    ) else (
        echo     Already present: %%~E
    )
)

:: ── Step 8: Patch linker flags ─────────────────────────────
echo   Patching linker flags...
set "LD_FILE=%BSP_P4%\flags\ld_libs"
for %%E in (
    "-lespressif__iot_usbh_ecm"
    "-lespressif__iot_usbh_cdc"
    "-lespressif__iot_eth"
    "-lusb_eth_deps"
    "-lusb_dwc_hal_shim"
) do (
    findstr /c:"%%~E" "%LD_FILE%" >nul 2>&1
    if errorlevel 1 (
        >> "%LD_FILE%" echo  %%~E
        echo     Added: %%~E
    ) else (
        echo     Already present: %%~E
    )
)

:: ── Step 9: Patch sdkconfig ────────────────────────────────
echo   Patching sdkconfig...
set "SDKCONFIG=%BSP_P4%\sdkconfig"

call :patch_config CONFIG_USB_HOST_ENABLE_ENUM_FILTER_CALLBACK y
call :patch_config CONFIG_LWIP_TCP_WND_DEFAULT 65535
call :patch_config CONFIG_LWIP_TCP_SND_BUF_DEFAULT 65535
call :patch_config CONFIG_LWIP_TCP_RECVMBOX_SIZE 32
call :patch_config CONFIG_LWIP_TCPIP_RECVMBOX_SIZE 32
call :patch_config CONFIG_LWIP_TCP_WND_SCALE y
call :patch_config CONFIG_LWIP_TCP_RCV_SCALE 3
call :patch_config CONFIG_LWIP_IRAM_OPTIMIZATION y

:: ── Done ───────────────────────────────────────────────────
echo.
echo ======================================================
echo   USBEth installed successfully!
echo.
echo   Library:   %ARDUINO_LIBS%\USBEth
echo   BSP patch: %BSP_P4%
echo.
echo   Next steps:
echo   1. Open Arduino IDE
echo   2. Select board: M5Stack Tab5
echo   3. File -^> Examples -^> USBEth -^> BasicEthernet
echo   4. Compile and flash
echo.
echo   To undo the BSP patch, restore the .bak files in:
echo   %BSP_P4%\lib\
echo   %BSP_P4%\flags\
echo   %BSP_P4%\sdkconfig.bak
echo ======================================================
pause
exit /b 0

:: ── Helper: patch a sdkconfig key ──────────────────────────
:patch_config
set "KEY=%~1"
set "VAL=%~2"
findstr /c:"%KEY%=%VAL%" "%SDKCONFIG%" >nul 2>&1
if not errorlevel 1 (
    echo     Already set: %KEY%=%VAL%
    goto :eof
)
findstr /c:"%KEY%=" "%SDKCONFIG%" >nul 2>&1
if not errorlevel 1 (
    powershell -Command "(Get-Content '%SDKCONFIG%') -replace '^%KEY%=.*', '%KEY%=%VAL%' | Set-Content '%SDKCONFIG%'"
    echo     Updated: %KEY%=%VAL%
    goto :eof
)
findstr /c:"# %KEY% is not set" "%SDKCONFIG%" >nul 2>&1
if not errorlevel 1 (
    powershell -Command "(Get-Content '%SDKCONFIG%') -replace '# %KEY% is not set', '%KEY%=%VAL%' | Set-Content '%SDKCONFIG%'"
    echo     Enabled: %KEY%=%VAL%
    goto :eof
)
>> "%SDKCONFIG%" echo %KEY%=%VAL%
echo     Added: %KEY%=%VAL%
goto :eof
