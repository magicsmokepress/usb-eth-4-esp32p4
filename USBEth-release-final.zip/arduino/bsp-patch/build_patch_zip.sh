#!/bin/bash
# build_patch_zip.sh — Create the Tab5 BSP patch zip for distribution
#
# Run from WSL after completing a lib-builder build.
# Collects all required .a files, headers, and the install script into a
# single zip that Tab5 users can download and run.
#
# Usage:
#   bash build_patch_zip.sh [path-to-esp32-arduino-lib-builder]
#
# Output: USBEth-tab5-bsp-patch.zip

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LIBBUILDER="${1:-$HOME/esp32-arduino-lib-builder}"
STAGING="/tmp/USBEth-tab5-bsp-patch"

# ── Find lib-builder output ─────────────────────────────────
OUT=$(find "$LIBBUILDER/out/tools/esp32-arduino-libs" -maxdepth 2 -type d -name "esp32p4" 2>/dev/null | head -1)
if [ -z "$OUT" ]; then
    echo "ERROR: Cannot find lib-builder output for esp32p4"
    echo "Usage: $0 [path-to-esp32-arduino-lib-builder]"
    exit 1
fi
echo "Lib-builder output: $OUT"

# ── Set up staging directory ─────────────────────────────────
rm -rf "$STAGING"
mkdir -p "$STAGING/lib" "$STAGING/include"

# ── Collect libraries ────────────────────────────────────────
echo "Collecting libraries..."
for lib in libusb.a liblwip.a libespressif__iot_usbh_ecm.a \
           libespressif__iot_usbh_cdc.a libespressif__iot_eth.a libusb_eth_deps.a; do
    if [ -f "$OUT/lib/$lib" ]; then
        cp "$OUT/lib/$lib" "$STAGING/lib/"
        echo "  ✓ $lib"
    else
        echo "  ✗ $lib — NOT FOUND"
    fi
done

# HAL shim (built separately via build_shim.sh)
if [ -f "$LIBBUILDER/libusb_dwc_hal_shim.a" ]; then
    cp "$LIBBUILDER/libusb_dwc_hal_shim.a" "$STAGING/lib/"
    echo "  ✓ libusb_dwc_hal_shim.a"
elif [ -f "$SCRIPT_DIR/lib/libusb_dwc_hal_shim.a" ]; then
    cp "$SCRIPT_DIR/lib/libusb_dwc_hal_shim.a" "$STAGING/lib/"
    echo "  ✓ libusb_dwc_hal_shim.a (from bsp-patch/lib/)"
else
    echo "  ✗ libusb_dwc_hal_shim.a — run build_shim.sh first!"
    exit 1
fi

# ── Collect headers ──────────────────────────────────────────
echo "Collecting headers..."
for comp in espressif__iot_eth espressif__iot_usbh_cdc espressif__iot_usbh_ecm usb_eth_deps; do
    if [ -d "$OUT/include/$comp" ]; then
        cp -r "$OUT/include/$comp" "$STAGING/include/"
        echo "  ✓ $comp/"
    else
        echo "  ✗ $comp/ — NOT FOUND"
    fi
done

# ── Copy install script ─────────────────────────────────────
cp "$SCRIPT_DIR/install.sh" "$STAGING/"
echo "  ✓ install.sh"

# ── Create zip ───────────────────────────────────────────────
OUTPUT_ZIP="$SCRIPT_DIR/USBEth-tab5-bsp-patch.zip"
cd /tmp
rm -f "$OUTPUT_ZIP"
zip -r "$OUTPUT_ZIP" "USBEth-tab5-bsp-patch/"
rm -rf "$STAGING"

echo
echo "═══════════════════════════════════════════════"
echo "  BSP patch zip created: $OUTPUT_ZIP"
echo "═══════════════════════════════════════════════"
echo
echo "Contents:"
unzip -l "$OUTPUT_ZIP"
echo
echo "To use: unzip, then run install.sh"
